package Test;

public class Department 
{
	String depAddr;
	public void addDep()
	{
		depAddr = "jyngr ";
	}
	public void printDep(int depId)
	{
		System.out.println("Department id is :" +depId);
		System.out.println("Department address is :" +depAddr);
	}
	public void descr(String name,int phone)
	{
		System.out.println("department name is:" +name);
		System.out.println("department phone number is:" +phone);
		
	}
	public static void main(String[] args) 
	
	{
		Department department= new Department();
		department.addDep();
		 department.printDep(20134);
		department.descr("hr",98765544);
	}

}
