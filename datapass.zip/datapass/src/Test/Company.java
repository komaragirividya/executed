//composition
package Test;

public class Company 
{ 
	Department department;
		String dName,eName;

	public String getDepartment() 
	{
		return dName;
	}


	public void setDepartment(String dName) 
	{
		this.dName = dName;
	}
	
	
	
	
	public String getEmployee() 
	{
		return eName;
	}


	public void setEmployee(String eName) 
	{
		this.eName = eName;
	}



	public static void main(String[] args) 
	{
		Company comp = new Company();
		
		Department d1 = new Department();
		comp.setDepartment("marketing");
		String c1=comp.getDepartment();
		
		Employee e1 = new Employee();
		comp.setEmployee("ram");
		String a1=comp.getEmployee();
		
		Department d2 = new Department();
		comp.setDepartment("dev");
		String c2=comp.getDepartment();
		
		Employee e2 = new Employee();
		comp.setEmployee("siva");
		String a2=comp.getEmployee();
		
		d1.descr(c1,1234); 
		e1.desc("ram","manager");
		
		d2.descr(c2,9888888);
		e2.desc("siva","accountant");
		
		
		
	}

}
