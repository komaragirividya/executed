package Test;

public class Employee 
  {
	int id,phone;
	String addr;

   public void addEmp()
    {
	   id = 209;
	   phone =987654;
	   addr = "mvm";	   
	}
    public void printEmp(int sal)
    {
    	
    	System.out.println("enter employee data is " +id);
    	System.out.println("employee phone is " +phone);
    	System.out.println("employee phone is " +addr);
    	System.out.println("employee phone is " +sal);
    
    }
    public void desc(String name,String desig)
    {
    	System.out.println("employee name is " +name);
    	System.out.println("employee designation is " +desig);
	}
	public static void main(String[] args) 
	{
		 Employee employee= new Employee();
		 employee.addEmp();
		 employee.printEmp(1000000);
		employee.desc("ram","manager");
		 
		 
		 
		 
		 
				 

	}

}
